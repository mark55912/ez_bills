# BILLS
Bills is a small DEB package that can be used to create a bills list.

## Installation

$ dpkg -i package

## Usage

Use to create a list of of your bills.

## License

EZ BILLS is release under the MIT license. See LICENSE for details.

## Contact

Email me at maclinunix@gmail.com
